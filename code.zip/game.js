// [ ⭐️ 시나리오 설정 영역 ⭐️ ]
const sceneConfig = {
    // 1: 시작 (배경음악 hallway)
    1:  { type: 'key', next: 2 },

    // 2~4: 0.4초 자동
    2:  { type: 'time', duration: 400, next: 3, bgm: 'hallway.mp3' },
    3:  { type: 'time', duration: 400, next: 4 },
    4:  { type: 'time', duration: 400, next: 5 },

    // 5~11: 엔터 입력
    5:  { type: 'key', next: 6 },
    6:  { type: 'key', next: 7 },
    7:  { type: 'key', next: 8 },
    8:  { type: 'key', next: 9 },
    9:  { type: 'key', next: 10 },
    10: { type: 'key', next: 11, sfx: 'ban.mp3' },
    11: { type: 'key', next: 12 },

    // 12: 분기점
    12: { type: 'input', choices: { 'no': 13, 'yes': '35-0' } }, 

    // === (1) NO 루트 ===
    13: { type: 'key', next: 14 },
    14: { type: 'key', next: 15, sfx: 'surprise.mp3' }, 
    15: { type: 'key', next: 16 },
    16: { type: 'key', next: 17 },

    // 17~21
    17: { type: 'time', duration: 500, next: 18 },
    18: { type: 'time', duration: 500, next: 19 },
    
    // 19: hallway 페이드 아웃 (2초), hit 소리
    19: { type: 'time', duration: 500, next: 20, fadeOutBgm: 2000, sfx: 'hit.mp3' },
    
    20: { type: 'time', duration: 500, next: '21-1' }, 
    '21-1': { type: 'time', duration: 500, next: '21-2' },
    '21-2': { type: 'time', duration: 500, next: 22 },

    // 22: student BGM 시작
    22: { type: 'key', next: 23, bgm: 'student.mp3' },
    23: { type: 'key', next: '23-1', sfx: 'ban.mp3' }, 

    // [ 23-1 분기 (키보드 무시) ]
    '23-1': { 
        type: 'choice', 
        nextA: 25, 
        nextB: '24-1', 
        nextEnter: 26,
        ignoreKey: true 
    },

    25: { type: 'key', next: '23-1' },
    '24-1': { type: 'key', next: '24-2' },
    '24-2': { type: 'key', next: '23-1', sfx: 'book.mp3' }, 

    // 26: 1차 비밀번호 (9030)
    // a -> 23-1
    26: { type: 'input', correct: '9030', next: '27-2', fail: 27, backKey: 'a', backScene: '23-1', typeSound: 'beep.mp3' },
    
    // 27: 2초간 보여줌, ban 소리
    27: { type: 'time', duration: 2000, next: '26-1', sfx: 'ban.mp3' }, 

    // 26-1: 2차 비밀번호
    '26-1': { type: 'input', correct: '9030', next: '27-2', fail: '27-0', backKey: 'a', backScene: '23-1', typeSound: 'beep.mp3' },

    // [히든 분기] 27-0 (ban 소리)
    '27-0': { type: 'key', next: '26-1', nextA: '27-1', sfx: 'ban.mp3' }, 
    '27-1': { type: 'key', next: '26-1', sfx: 'hint.mp3' },

    // 27-2 (1.5초) -> door_open -> 28
    '27-2': { type: 'time', duration: 1500, next: 28, sfx: 'door_open.mp3' },

    // 28: hallway BGM 다시 시작
    28: { type: 'key', next: 29, bgm: 'hallway.mp3' },
    29: { type: 'key', next: 30 },
    30: { type: 'key', next: 31 },
    31: { type: 'key', next: 32 },
    32: { type: 'key', next: 33 },
    33: { type: 'key', next: 34, sfx: 'memo.mp3' }, 
    34: { type: 'key', next: 37 }, 

    // === (2) YES 루트 ===
    '35-0': { type: 'key', next: '35-1' },
    '35-1': { type: 'key', next: 36 },
    36: { type: 'key', next: 33 }, 

    // --- 37~50 공통 ---
    // 37: simhwa BGM 시작
    37: { type: 'key', next: 38, bgm: 'simhwa.mp3' },
    38: { type: 'key', next: 39 },
    39: { type: 'key', next: 40 },
    40: { type: 'key', next: 41 },
    41: { type: 'key', next: 42 },
    
    // 42: 1초, fast 소리 (0.5초 딜레이)
    42: { type: 'time', duration: 1000, next: 43, sfx: 'fast.mp3', sfxDelay: 500 },
    
    43: { type: 'key', next: 44 },
    44: { type: 'key', next: 45 },
    45: { type: 'key', next: 46 },
    46: { type: 'key', next: 47 },
    47: { type: 'key', next: 48 },
    48: { type: 'key', next: 49 },
    49: { type: 'key', next: 50 },
    50: { type: 'key', next: 51 },

    // 51: YES / NO
    51: { type: 'input', choices: { 'yes': 52, 'no': 63 } },

    // === 51번 (1) YES 루트 ===
    52: { type: 'key', next: 53 },
    53: { type: 'key', next: 54 },
    
    // 54->55 book
    54: { type: 'key', next: 55 },
    
    // 55->56 book
    55: { type: 'key', next: 56, sfx: 'book.mp3' },
    
    // 56: 숫자 '5' 입력
    56: { 
        type: 'input', 
        correct: '5', 
        next: 57, 
        fail: '56-1', 
        correctSfx: 'correct.mp3',
        backKey: 'a', 
        backScene: 55,
        backSfx: 'book.mp3' 
    },
    '56-1': { type: 'key', next: 56, sfx: 'sigh.mp3' }, 

    57: { type: 'key', next: 58 },
    58: { type: 'key', next: 59, sfx: 'memo.mp3' }, 
    59: { type: 'key', next: 60 },
    60: { type: 'key', next: 61 },

    // 61: 'ON' 입력
    61: { type: 'input', correct: ['on', 'ON'], next: 62 },
    
    // 61->62 turnon 소리
    62: { type: 'key', next: 77, sfx: 'turnon.mp3' },

    // === 51번 (2) NO 루트 ===
    // 63: pow 소리, scare BGM
    63: { type: 'key', next: 64, sfx: 'pow.mp3', bgm: 'scare.mp3' },
    64: { type: 'key', next: 65 },
    65: { type: 'key', next: 66 },
    66: { type: 'key', next: 67 },
    67: { type: 'key', next: '67-1' },
    '67-1': { type: 'key', next: 68 },
    
    // 68: electronic 소리
    68: { type: 'key', next: 69, sfx: 'electronic.mp3' },
    69: { type: 'key', next: 70 },
    70: { type: 'key', next: 71 },
    71: { type: 'key', next: 72 },
    72: { type: 'key', next: 73 },

    // 73: 숫자 '1' 입력
    73: { type: 'input', correct: '1', next: 74, fail: '74-1' },

    // 74: 정답 (3초, usb_siren BGM)
    74:   { type: 'time', duration: 3000, next: '75-1', bgm: 'usb_siren.mp3' }, 
    '74-1': { type: 'time', duration: 3000, next: '75-1', bgm: 'usb_siren.mp3' },

    '75-1': { type: 'key', next: '75-2' },
    '75-2': { type: 'key', next: '75-3' },
    '75-3': { type: 'key', next: '76-0' },

    // 76-0: glitch 소리, 2.5초간 보임
    '76-0': { type: 'time', duration: 2500, next: '76-1', sfx: 'glitch.mp3' },
    
    // 76-1: 엔딩 (fail BGM)
    '76-1': { type: 'end', message: "게임 종료.\n불쌍한 대학원생을 매몰차게 외면한 당신은\n그 업보로 대학원생이 되었습니다.", bgm: 'fail.mp3' },

    // --- 77~78 (공통) ---
    // 77: professor BGM 시작
    77: { type: 'key', next: 78, bgm: 'professor.mp3' },
    78: { type: 'key', next: 79 },

    // 79: 선택지 (A)/(B) (클릭만)
    79: { type: 'choice', nextA: 80, nextB: 90, ignoreKey: true },

    // === 79-(A) 루트 ===
    80: { type: 'key', next: 81 },
    81: { type: 'key', next: 82 },
    82: { type: 'key', next: 83 },

    // 83: '88' 입력 (beep, ban)
    // a -> 82
    83: { type: 'input', correct: '88', next: 84, fail: '83-1', typeSound: 'beep.mp3', backKey: 'a', backScene: 82 },
    '83-1': { type: 'time', duration: 2000, next: '83-0', sfx: 'ban.mp3' }, 

    // 83-0: 2차 입력
    '83-0': { type: 'input', correct: '88', next: 84, fail: '83-2', typeSound: 'beep.mp3', backKey: 'a', backScene: 82 },
    
    // [히든 분기] 83-2 (ban 소리)
    '83-2': { type: 'key', next: '83-0', nextA: '83-3', sfx: 'ban.mp3' },
    '83-3': { type: 'key', next: '83-0', sfx: 'hint.mp3' },

    // 84: 2초, box_open 소리
    84: { type: 'time', duration: 2000, next: '84-1', sfx: 'box_open.mp3' },

    // 84-1: 선택지 (a)/(b) (클릭만)
    '84-1': { type: 'choice', nextA: 85, nextB: 94, ignoreKey: true },

    // --- 84-(a) 루트 ---
    // 85: button_siren BGM
    85: { type: 'key', next: 86, bgm: 'button_siren.mp3' }, 
    86: { type: 'key', next: 87 },
    
    // 87: glitch 소리, 2.5초 (BGM 안 끔)
    87: { type: 'time', duration: 2500, next: 88, sfx: 'glitch.mp3' },
    
    // 88: 3초, fail BGM 1.5초 딜레이
    88: { type: 'time', duration: 3000, next: 89, bgm: 'fail.mp3', bgmDelay: 1500 }, 
    
    // 89: 엔딩
    89: { type: 'end', message: "게임 종료.\n말을 듣지 않는 당신은\n대학원생이 되어 창조관에 영원히 갇히게 되었습니다." },

    // === 79-(B) 루트 ===
    // 90: love 소리
    90: { type: 'key', next: 91, sfx: 'love.mp3' },
    
    // 91: glitch 소리, 2초, 배경음악 끔
    91: { type: 'time', duration: 2000, next: 92, sfx: 'glitch.mp3', bgm: 'stop' },
    
    // 92: 3초, fail BGM 1초 딜레이
    92: { type: 'time', duration: 3000, next: 93, bgm: 'fail.mp3', bgmDelay: 1000 }, 
    
    // 93: 엔딩
    93: { type: 'end', message: "게임 종료.\n신중하지 못한 당신은\n대학원생이 되어 창조관에 영원히 갇히게 되었습니다." },

    // =================================================================
    // 94번 이후
    // =================================================================
    
    // 94: empty BGM 시작
    94: { type: 'key', next: 95, bgm: 'empty.mp3' },
    95: { type: 'key', next: 98 }, 
    98: { type: 'key', next: 99 },
    99: { type: 'key', next: 100 },
    100: { type: 'key', next: 101 },
    101: { type: 'key', next: 102 },
    
    // 101->102 넘어갈 때 memo 소리
    102: { type: 'key', next: 103, sfx: 'memo.mp3' },

    // 103: '47' 입력
    // 정답 -> 103-4
    // 오답 -> 103-1
    103: { type: 'input', correct: '47', next: '103-4', fail: '103-1' },
    '103-1': { type: 'time', duration: 2000, next: '103-0', sfx: 'ban.mp3' },

    // 103-0: '47' 재입력
    '103-0': { type: 'input', correct: '47', next: '103-4', fail: '103-2' },
    
    // [히든 분기] 103-2
    '103-2': { type: 'key', next: '103-0', nextA: '103-3', sfx: 'ban.mp3' },
    '103-3': { type: 'key', next: '103-0', sfx: 'hint.mp3' },

    // 103-4 ~ 103-8
    '103-4': { type: 'key', next: '103-5', sfx: 'correct.mp3' }, // correct 소리
    '103-5': { type: 'key', next: '103-6' },
    '103-6': { type: 'key', next: '103-7', sfx: 'fast.mp3' }, // fast 소리
    '103-7': { type: 'key', next: '103-8' },
    '103-8': { type: 'key', next: 104 },

    // 104~107 (1.2초 자동)
    // 104: empty BGM 끄기, walk 소리 재생 (지속됨)
    104: { type: 'time', duration: 1200, next: 105, bgm: 'stop', sfx: 'walk.mp3' },
    105: { type: 'time', duration: 1200, next: 106 },
    106: { type: 'time', duration: 1200, next: 107 },
    
    // 107: hallway BGM 페이드 인 (2초)
    107: { type: 'time', duration: 1200, next: 108, fadeInBgm: { file: 'hallway.mp3', duration: 2000 } },

    // 108
    108: { type: 'key', next: '108-0' },
    '108-0': { type: 'key', next: '108-1', sfx: 'memo.mp3' }, 

    // 108-1: '483747' 입력 (소리 없음)
    '108-1': { type: 'input', correct: '483747', next: 109, fail: '108-3' },
    
    // 108-2: 사용 안 함 (108-1에서 바로 108-3이나 109로 감)

    // [히든 분기] 108-3 (ban 소리)
    // 엔터 -> 108-1
    // a -> 108-4
    '108-3': { type: 'key', next: '108-1', nextA: '108-4', sfx: 'ban.mp3' },
    
    // 108-4 ~ 108-8 히든 루트
    '108-4': { type: 'key', next: '108-5', sfx: 'hint.mp3' },
    '108-5': { type: 'key', next: '108-6' },
    '108-6': { type: 'key', next: '108-7' },
    '108-7': { type: 'key', next: '108-8' },
    '108-8': { type: 'key', next: '108-1' },

    // 109: elv_open 소리, BGM 끄기
    109: { type: 'key', next: 110, sfx: 'elv_open.mp3', bgm: 'stop' },
    
    // 110: escape BGM
    110: { type: 'key', next: '110-1', bgm: 'escape.mp3' },
    '110-1': { type: 'key', next: '110-2' },

    // [가위바위보] 110-2
    '110-2': { type: 'rps' },
    
    '110-3': { type: 'time', duration: 1500, next: '110-2', sfx: 'card.mp3' }, 
    '110-4': { type: 'time', duration: 1500, next: '110-2', sfx: 'card.mp3' }, 
    '110-5': { type: 'time', duration: 1500, next: '110-2', sfx: 'card.mp3' }, 

    // 111: '052' 입력
    // a -> 110-2
    // 정답 -> 111-4
    // 오답 -> 111-1
    111: { 
        type: 'input', correct: '052', next: '111-4', fail: '111-1', 
        backKey: 'a', backScene: '110-2' 
    },
    '111-1': { type: 'time', duration: 2000, next: '111-0', sfx: 'ban.mp3' }, 

    // 111-0: 재입력
    '111-0': { 
        type: 'input', correct: '052', next: '111-4', fail: '111-2',
        backKey: 'a', backScene: '110-2'
    },

    // [히든 분기] 111-2
    '111-2': { type: 'key', next: '111-0', nextA: '111-3', sfx: 'ban.mp3' },
    '111-3': { type: 'key', next: '111-0', sfx: 'hint.mp3' },

    // 111-4: 정답 화면 (2초), victory BGM
    '111-4': { type: 'time', duration: 2000, next: 112, bgm: 'victory.mp3' },

    // 112~114 (0.8초)
    112: { type: 'time', duration: 800, next: 113 },
    113: { type: 'time', duration: 800, next: 114 },
    114: { type: 'time', duration: 800, next: 115 },

    // 115~116 (엔터)
    // 115: 배경음악 페이드 아웃 (1초)
    115: { type: 'key', next: 116, fadeOutBgm: 1000 },
    116: { type: 'key', next: 117 },

    // 117~120 (0.5초)
    117: { type: 'time', duration: 500, next: 118 },
    // 118: mirae_ending BGM 시작
    118: { type: 'time', duration: 500, next: 119, bgm: 'mirae_ending.mp3' },
    119: { type: 'time', duration: 500, next: 120 },

    // 120: 최종 엔딩
    120: { type: 'end', message: "이젠 미래관을 탈출해보세요!" }
};

// -------------------------------------------------------------------
// [ ⭐️ 게임 엔진 코드 ⭐️ ]
// -------------------------------------------------------------------

const gameScreen = document.getElementById('game-screen');
const inputArea = document.getElementById('input-area');
const textInput = document.getElementById('text-input');
const submitButton = document.getElementById('submit-button');
const choiceArea = document.getElementById('choice-area');
const btnA = document.getElementById('btn-a');
const btnB = document.getElementById('btn-b');
const rpsArea = document.getElementById('rps-area');
const btnScissors = document.getElementById('btn-scissors');
const btnRock = document.getElementById('btn-rock');
const btnPaper = document.getElementById('btn-paper');
const btnSolve = document.getElementById('btn-solve');

let currentScene = 1;
let isWaitingForInput = false;
let canPressEnter = false;
let rpsState = { scissors: false, rock: false, paper: false };

let currentBgmAudio = null;
let currentBgmFile = "";
let fadeInterval = null; 
let crossfadeInterval = null;

function playBgm(fileName) {
    stopAllFades(); 

    if (!fileName) { 
        if (currentBgmAudio) {
            currentBgmAudio.pause();
            currentBgmAudio.currentTime = 0;
        }
        currentBgmFile = "";
        return;
    }

    if (currentBgmFile === fileName) {
        if(currentBgmAudio) currentBgmAudio.volume = 0.5; 
        return;
    }

    if (currentBgmAudio) {
        currentBgmAudio.pause();
        currentBgmAudio.currentTime = 0;
    }

    currentBgmAudio = new Audio(fileName);
    currentBgmAudio.loop = true;
    currentBgmAudio.volume = 0.5;
    currentBgmAudio.play().catch(e => console.log("자동재생 제한"));
    
    currentBgmFile = fileName;
}

function fadeOutBgm(duration) {
    if (!currentBgmAudio) return;
    stopAllFades();

    const steps = 20;
    const intervalTime = duration / steps;
    const volStep = currentBgmAudio.volume / steps;

    fadeInterval = setInterval(() => {
        if (currentBgmAudio.volume > volStep) {
            currentBgmAudio.volume -= volStep;
        } else {
            currentBgmAudio.volume = 0;
            currentBgmAudio.pause();
            currentBgmFile = "";
            clearInterval(fadeInterval);
        }
    }, intervalTime);
}

function fadeInBgm(fileName, duration) {
    stopAllFades();
    
    if (currentBgmAudio) {
        currentBgmAudio.pause();
    }

    currentBgmAudio = new Audio(fileName);
    currentBgmAudio.loop = true;
    currentBgmAudio.volume = 0; 
    currentBgmAudio.play().catch(e => console.log("자동재생 제한"));
    currentBgmFile = fileName;

    const targetVol = 0.5;
    const steps = 20;
    const intervalTime = duration / steps;
    const volStep = targetVol / steps;

    fadeInterval = setInterval(() => {
        if (currentBgmAudio.volume < targetVol - volStep) {
            currentBgmAudio.volume += volStep;
        } else {
            currentBgmAudio.volume = targetVol;
            clearInterval(fadeInterval);
        }
    }, intervalTime);
}

function crossfadeBgm(outDuration, inFile, inDuration) {
    stopAllFades();

    const oldAudio = currentBgmAudio;
    if (oldAudio) {
        const outSteps = 20;
        const outInterval = outDuration / outSteps;
        const outStepVol = oldAudio.volume / outSteps;

        let outTimer = setInterval(() => {
            if (oldAudio.volume > outStepVol) {
                oldAudio.volume -= outStepVol;
            } else {
                oldAudio.volume = 0;
                oldAudio.pause();
                clearInterval(outTimer);
            }
        }, outInterval);
    }

    const newAudio = new Audio(inFile);
    newAudio.loop = true;
    newAudio.volume = 0;
    newAudio.play().catch(e => console.log("자동재생 제한"));
    
    currentBgmAudio = newAudio;
    currentBgmFile = inFile;

    const targetVol = 0.5;
    const inSteps = 20;
    const inInterval = inDuration / inSteps;
    const inStepVol = targetVol / inSteps;

    crossfadeInterval = setInterval(() => {
        if (newAudio.volume < targetVol - inStepVol) {
            newAudio.volume += inStepVol;
        } else {
            newAudio.volume = targetVol;
            clearInterval(crossfadeInterval);
        }
    }, inInterval);
}

function stopAllFades() {
    if (fadeInterval) clearInterval(fadeInterval);
    if (crossfadeInterval) clearInterval(crossfadeInterval);
}

function playSfx(fileName) {
    if (!fileName) return;
    const sfx = new Audio(fileName);
    sfx.volume = 0.8;
    sfx.play().catch(e => console.log("재생 실패"));
}

function setScene(sceneNumber) {
    currentScene = sceneNumber;
    const config = sceneConfig[sceneNumber];

    isWaitingForInput = false;
    canPressEnter = false;
    inputArea.classList.add('hidden');
    choiceArea.classList.add('hidden');
    rpsArea.classList.add('hidden');

    if (!config) {
        console.log(`장면 ${sceneNumber} 설정 오류`);
        return;
    }

    if (sceneNumber === '35-0' && config.next === '35-1') {}

    gameScreen.src = `${sceneNumber}.png`;

    if (config.crossfade) {
        crossfadeBgm(config.crossfade.outDuration, config.crossfade.inFile, config.crossfade.inDuration);
    } 
    else if (config.fadeInBgm) {
        fadeInBgm(config.fadeInBgm.file, config.fadeInBgm.duration);
    }
    else if (config.fadeOutBgm) {
        fadeOutBgm(config.fadeOutBgm);
    }
    else if (config.bgm === 'stop') {
        playBgm(null);
    }
    else if (config.bgm) {
        if (config.bgmDelay) {
            playBgm(null);
            setTimeout(() => {
                if (currentScene == sceneNumber) {
                    playBgm(config.bgm);
                }
            }, config.bgmDelay);
        } else {
            playBgm(config.bgm);
        }
    }

    if (config.sfx) {
        if (config.sfxDelay) {
            setTimeout(() => {
                if (currentScene == sceneNumber) {
                    playSfx(config.sfx);
                }
            }, config.sfxDelay);
        } else {
            playSfx(config.sfx);
        }
    }

    if (config.type === 'end') {
        if (config.message) {
            setTimeout(() => { alert(config.message); }, 300);
        }
        return;
    }

    switch (config.type) {
        case 'time':
            setTimeout(() => { setScene(config.next); }, config.duration);
            break;

        case 'input':
            if (currentScene == 12) {}
            setTimeout(() => {
                isWaitingForInput = true;
                inputArea.classList.remove('hidden');
                textInput.value = '';
                textInput.focus();
            }, 100);
            break;
            
        case 'choice':
            choiceArea.classList.remove('hidden');
            btnA.onclick = () => setScene(config.nextA);
            btnB.onclick = () => setScene(config.nextB);
            if (config.nextEnter) {
                setTimeout(() => { canPressEnter = true; }, 100);
            }
            break;

        case 'rps':
            rpsArea.classList.remove('hidden');
            if (rpsState.scissors && rpsState.rock && rpsState.paper) {
                btnSolve.classList.remove('hidden-btn');
            } else {
                btnSolve.classList.add('hidden-btn');
            }
            btnScissors.onclick = () => { rpsState.scissors = true; setScene('110-3'); };
            btnRock.onclick = () => { rpsState.rock = true; setScene('110-4'); };
            btnPaper.onclick = () => { rpsState.paper = true; setScene('110-5'); };
            btnSolve.onclick = () => { setScene(111); };
            break;
            
        case 'key':
            break;
    }
}

function handleSubmit() {
    if (!isWaitingForInput) return;
    const config = sceneConfig[currentScene];
    let value = textInput.value.trim();
    if (!value) return;

    if (config.choices) {
        let nextScene = config.choices[value.toLowerCase()];
        if (currentScene == 12 && value.toLowerCase() === 'yes') {
            nextScene = '35-0';
        }

        if (nextScene) {
            setScene(nextScene);
        } else {
            alert("YES 또는 NO를 입력해주세요.");
            textInput.value = '';
            textInput.focus();
        }
    } else if (config.correct) {
        const isCorrect = Array.isArray(config.correct) ? config.correct.includes(value) : value === config.correct;
        if (isCorrect) {
            if (config.correctSfx) playSfx(config.correctSfx);
            setScene(config.next);
        } else {
            if (config.fail) { setScene(config.fail); }
            else if (config.failAlert) { alert(config.failAlert); textInput.value = ''; textInput.focus(); }
            else { textInput.value = ''; textInput.focus(); }
        }
    }
}

textInput.addEventListener('input', () => {
    const config = sceneConfig[currentScene];
    if (isWaitingForInput && config && config.typeSound) {
        const beep = new Audio(config.typeSound);
        beep.volume = 0.4;
        beep.play().catch(() => {});
    }
});

document.addEventListener('keydown', (event) => {
    const config = sceneConfig[currentScene];
    const key = event.key;

    if (config.ignoreKey && key !== 'Enter') {
        return; 
    }

    if (isWaitingForInput && config && config.backKey && key.toLowerCase() === config.backKey) {
        if (config.backSfx) playSfx(config.backSfx);
        setScene(config.backScene);
        return;
    }

    if (key === 'Enter' && !isWaitingForInput && config && config.type === 'key') {
        setScene(config.next);
        return;
    }
    
    if (key === 'Enter' && config && config.type === 'choice' && config.nextEnter && canPressEnter) {
        setScene(config.nextEnter);
        return;
    }
    
    if (key.toLowerCase() === 'a' && !isWaitingForInput && config && config.nextA) {
        setScene(config.nextA);
        return;
    }
    if (key === 'Enter' && isWaitingForInput) {
        handleSubmit();
    }
});

submitButton.addEventListener('click', handleSubmit);
window.onload = () => { setScene(1); };